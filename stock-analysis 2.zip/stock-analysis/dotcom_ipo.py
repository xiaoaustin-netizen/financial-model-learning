import streamlit as st
import yfinance as yf
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import warnings

warnings.filterwarnings("ignore")

st.set_page_config(page_title="Dotcom IPO Tracker", layout="wide", page_icon="📡")

st.markdown("""
<style>
    .block-container { padding-top: 1.2rem; padding-bottom: 2rem; }
    h1 { color: #F0F0F0; font-size: 1.9rem; font-weight: 700; letter-spacing: -0.5px; }

    .section-header {
        font-size: 0.68rem; font-weight: 700; letter-spacing: 0.12em;
        text-transform: uppercase; color: #6B7280;
        padding: 2px 0 6px 0; border-bottom: 1px solid #252525; margin-bottom: 12px;
    }
    .stat-card {
        background: #151515; border: 1px solid #2a2a2a; border-radius: 10px;
        padding: 14px 16px; position: relative; overflow: hidden;
    }
    .stat-card-bar { position: absolute; top: 0; left: 0; right: 0; height: 3px; }
    .stat-ticker  { font-size: 0.72rem; color: #6B7280; font-weight: 500; }
    .stat-company { font-size: 0.9rem; color: #F0F0F0; font-weight: 700; margin: 2px 0; }
    .stat-return  { font-size: 1.5rem; font-weight: 800; line-height: 1.1; }
    .stat-label   { font-size: 0.7rem; color: #6B7280; margin-top: 2px; }
    .stat-cagr    { font-size: 0.78rem; color: #9CA3AF; margin-top: 6px; }

    .ev-block {
        padding: 9px 12px; border-radius: 8px; margin-bottom: 7px;
        background: #151515; border: 1px solid #242424;
    }
    .ev-date  { font-size: 0.7rem; color: #9CA3AF; font-weight: 500; }
    .ev-label { font-size: 0.83rem; font-weight: 700; margin: 2px 0 1px; }
    .ev-desc  { font-size: 0.77rem; color: #C8D6E5; line-height: 1.4; margin-top: 3px; }

    /* Projection methodology box */
    .method-box {
        background: #0f1117; border: 1px solid #2a2a2a; border-radius: 10px;
        padding: 14px 18px; margin-bottom: 14px; font-size: 0.8rem;
    }
    .method-row { display: flex; justify-content: space-between; padding: 3px 0; color: #C8D6E5; }
    .method-key { color: #9CA3AF; }
    .method-total {
        display: flex; justify-content: space-between;
        border-top: 1px solid #333; margin-top: 6px; padding-top: 6px;
        font-weight: 700; font-size: 0.85rem; color: #F0F0F0;
    }
    .adj-pos { color: #00E676; }
    .adj-neg { color: #FF4B4B; }
    .adj-neu { color: #9CA3AF; }

    /* news checkbox styling */
    .news-pos { color: #00E676; font-size: 0.75rem; }
    .news-neg { color: #FF4B4B; font-size: 0.75rem; }
</style>
""", unsafe_allow_html=True)

# ═══════════════════════════════════════════════════════════════════════════════
# Static data
# ═══════════════════════════════════════════════════════════════════════════════

COMPANIES = {
    "Amazon":          {"ticker": "AMZN", "ipo_date": "1997-05-15", "sector": "E-Commerce",    "color": "#FF9900"},
    "eBay":            {"ticker": "EBAY", "ipo_date": "1998-09-24", "sector": "E-Commerce",    "color": "#E53238"},
    "Booking Holdings":{"ticker": "BKNG", "ipo_date": "1999-03-30", "sector": "E-Commerce",    "color": "#00C8A0"},
    "Akamai":          {"ticker": "AKAM", "ipo_date": "1999-10-29", "sector": "Infrastructure", "color": "#F72585"},
    "Qualcomm":        {"ticker": "QCOM", "ipo_date": "1999-01-01", "sector": "Infrastructure", "color": "#4CC9F0"},
    "VeriSign":        {"ticker": "VRSN", "ipo_date": "1998-01-30", "sector": "Infrastructure", "color": "#9B5DE5"},
}

EVENTS = {
    "Amazon": [
        {"date": "1997-05-15", "type": "ipo",       "label": "IPO",         "desc": "IPO at $18/share; books 3× oversubscribed"},
        {"date": "1999-12-09", "type": "peak",      "label": "Dotcom peak", "desc": "Hits $113 adj; Bezos named TIME Person of the Year"},
        {"date": "2001-09-28", "type": "crash",     "label": "−94% bottom", "desc": "Crashes to $5.97; analysts predict bankruptcy"},
        {"date": "2005-02-02", "type": "milestone", "label": "Prime",       "desc": "Amazon Prime launched at $79/yr"},
        {"date": "2006-03-14", "type": "milestone", "label": "AWS launch",  "desc": "S3 + EC2 go public; cloud computing is born"},
        {"date": "2007-11-19", "type": "milestone", "label": "Kindle",      "desc": "Kindle sells out in 5.5 hours"},
        {"date": "2018-09-04", "type": "milestone", "label": "$1T club",    "desc": "Joins Apple as second $1T US company"},
        {"date": "2020-07-02", "type": "macro",     "label": "COVID surge", "desc": "Lockdowns push e-commerce to record $88.9B revenue"},
        {"date": "2022-01-03", "type": "peak",      "label": "ATH",         "desc": "All-time high ~$188 split-adj"},
        {"date": "2022-12-28", "type": "crash",     "label": "Rate selloff","desc": "Fed hikes crush multiples; −55% from ATH in 2022"},
    ],
    "eBay": [
        {"date": "1998-09-24", "type": "ipo",       "label": "IPO",         "desc": "IPO at $18; closes $47.38 — 163% first-day gain"},
        {"date": "1999-12-10", "type": "peak",      "label": "Dotcom peak", "desc": "$21B market cap on $225M revenue — 93× sales"},
        {"date": "2001-03-15", "type": "crash",     "label": "−80%",        "desc": "Dotcom bust pulls eBay down 80% from peak"},
        {"date": "2002-10-03", "type": "milestone", "label": "PayPal acq.", "desc": "$1.5B PayPal acquisition — defines eBay for a decade"},
        {"date": "2015-07-17", "type": "milestone", "label": "PayPal spin", "desc": "PayPal spun off; shareholders receive $30B+ in stock"},
        {"date": "2020-03-11", "type": "macro",     "label": "COVID boost", "desc": "Pandemic drives second-hand goods boom; GMV +26%"},
    ],
    "Booking Holdings": [
        {"date": "1999-03-30", "type": "ipo",       "label": "IPO",          "desc": "Priceline IPO at $16; surges to $88 on day one"},
        {"date": "2001-11-01", "type": "crash",     "label": "−99% bottom",  "desc": "Falls to $1.06; lays off 100% of staff, sells jets"},
        {"date": "2005-07-01", "type": "milestone", "label": "Booking.com",  "desc": "$133M Booking.com buy — the deal that saved them"},
        {"date": "2014-04-14", "type": "milestone", "label": "First $1,000", "desc": "First S&P 500 stock to hit $1,000/share"},
        {"date": "2020-03-11", "type": "crash",     "label": "COVID −55%",   "desc": "Global travel bans collapse revenue 90%"},
        {"date": "2022-06-01", "type": "milestone", "label": "Revenge travel","desc": "Post-COVID boom; record $4B+ quarterly revenue"},
    ],
    "Akamai": [
        {"date": "1999-10-29", "type": "ipo",       "label": "IPO",          "desc": "IPO at $26; closes $145 — 459% first-day gain"},
        {"date": "1999-12-31", "type": "peak",      "label": "$345 peak",    "desc": "$33B mkt cap on $4M revenue — 8,250× sales"},
        {"date": "2001-09-11", "type": "crash",     "label": "−99.7% + 9/11","desc": "Co-founder killed on Flight 11; stock at $1.01"},
        {"date": "2007-06-01", "type": "milestone", "label": "Profitable",   "desc": "First consistent profitability; CDN proven essential"},
        {"date": "2020-03-11", "type": "macro",     "label": "COVID traffic","desc": "Remote work spikes internet traffic 30%"},
        {"date": "2022-12-01", "type": "milestone", "label": "Cloud pivot",  "desc": "Linode deal completes; rebranded as Akamai Cloud"},
    ],
    "Qualcomm": [
        {"date": "1999-01-01", "type": "peak",      "label": "+2,619%",      "desc": "Best S&P 500 stock of 1999; CDMA wins wireless war"},
        {"date": "2000-12-31", "type": "crash",     "label": "−65%",         "desc": "Dotcom bust; patent-era euphoria deflates"},
        {"date": "2017-01-20", "type": "crash",     "label": "Apple lawsuit","desc": "Apple sues over royalties; $31B battle begins"},
        {"date": "2019-04-16", "type": "milestone", "label": "Apple settles","desc": "$4.5B settlement; stock +23% in a single day"},
        {"date": "2020-09-01", "type": "milestone", "label": "5G supercycle","desc": "Snapdragon in every major 5G flagship"},
        {"date": "2024-01-01", "type": "milestone", "label": "AI edge",      "desc": "Snapdragon X Elite — on-device AI boom begins"},
    ],
    "VeriSign": [
        {"date": "1998-01-30", "type": "ipo",       "label": "IPO",          "desc": "IPO at $21; SSL certificates and domain security"},
        {"date": "2000-01-21", "type": "peak",      "label": "$258 peak",    "desc": "Acquires Network Solutions for $21B"},
        {"date": "2002-07-12", "type": "crash",     "label": "−99%",         "desc": "Falls to $3.60; sold 13 of 14 acquired businesses"},
        {"date": "2006-11-01", "type": "milestone", "label": ".COM monopoly","desc": "Perpetual .com registry deal with ICANN secured"},
        {"date": "2020-01-01", "type": "milestone", "label": "150M .coms",   "desc": "150M+ domains; $110M/yr near-zero-capex cashflow"},
    ],
}

TYPE_META = {
    "ipo":       {"color": "#29B6F6", "icon": "🚀"},
    "peak":      {"color": "#FFD700", "icon": "📈"},
    "crash":     {"color": "#FF4B4B", "icon": "📉"},
    "milestone": {"color": "#00E676", "icon": "⭐"},
    "macro":     {"color": "#AB47BC", "icon": "🌍"},
}

# ── IPO comp definitions ─────────────────────────────────────────────────────────

IPO_COMPS = {
    "OpenAI": {
        "desc": "AI platform · ~$300B private valuation · $3.7B ARR (2024)",
        "color": "#10B981",
        "comps": [
            {"name": "Google",    "ticker": "GOOGL", "ipo_date": "2004-08-19"},
            {"name": "Meta",      "ticker": "META",  "ipo_date": "2012-05-18"},
            {"name": "Palantir",  "ticker": "PLTR",  "ipo_date": "2020-09-30"},
            {"name": "Snowflake", "ticker": "SNOW",  "ipo_date": "2020-09-16"},
        ],
    },
    "SpaceX": {
        "desc": "Launch + Starlink · ~$350B private valuation · 70%+ global launch share",
        "color": "#6366F1",
        "comps": [
            {"name": "Tesla",       "ticker": "TSLA", "ipo_date": "2010-06-29"},
            {"name": "Rocket Lab",  "ticker": "RKLB", "ipo_date": "2021-08-25"},
            {"name": "V. Galactic", "ticker": "SPCE", "ipo_date": "2019-10-28"},
            {"name": "Boeing",      "ticker": "BA",   "ipo_date": "1962-01-02"},
        ],
    },
}

COMP_COLORS = {
    "GOOGL": "#4285F4", "META": "#1877F2", "PLTR": "#A78BFA", "SNOW": "#29B6F6",
    "TSLA":  "#E31937", "RKLB": "#FF6B35", "SPCE": "#C084FC", "BA":   "#0033A0",
}

# ── Projection adjustment tables ─────────────────────────────────────────────────
# All deltas are in monthly return (e.g. 0.002 = +0.2%/mo ≈ +2.4%/yr)

MACRO_OPTIONS = ["Deep Bear 🐻", "Bear", "Neutral", "Bull", "Strong Bull 🚀"]
MACRO_ADJ     = {"Deep Bear 🐻": -0.005, "Bear": -0.002, "Neutral": 0.0, "Bull": +0.002, "Strong Bull 🚀": +0.005}

GROWTH_OPTIONS = ["Much slower", "Slower", "In line with comps", "Faster", "Much faster"]
GROWTH_ADJ     = {"Much slower": -0.004, "Slower": -0.002, "In line with comps": 0.0, "Faster": +0.003, "Much faster": +0.006}

VALUATION_OPTIONS = ["Bargain (deep discount)", "Fair value", "Premium (20%+ rich)", "Bubble territory"]
VALUATION_ADJ     = {"Bargain (deep discount)": +0.003, "Fair value": 0.0, "Premium (20%+ rich)": -0.003, "Bubble territory": -0.006}

VOL_OPTIONS = ["Low (calm market)", "Normal", "Elevated", "Very high"]
VOL_MULT    = {"Low (calm market)": 0.75, "Normal": 1.0, "Elevated": 1.3, "Very high": 1.6}

# Each item: text shown, monthly delta, checked by default
NEWS_ITEMS = {
    "OpenAI": [
        {"text": "Microsoft Copilot / Azure integration expanding",  "delta": +0.0015, "default": True,  "sign": "+"},
        {"text": "ChatGPT Enterprise: 92% Fortune 500 adoption",    "delta": +0.0010, "default": True,  "sign": "+"},
        {"text": "Revenue growing faster than compute cost",        "delta": +0.0020, "default": False, "sign": "+"},
        {"text": "Custom AI chips / hardware play in development",  "delta": +0.0008, "default": False, "sign": "+"},
        {"text": "EU AI Act compliance burden rising",              "delta": -0.0010, "default": False, "sign": "−"},
        {"text": "Meta Llama / open-source competition intensifying","delta": -0.0012, "default": True,  "sign": "−"},
        {"text": "US antitrust scrutiny of Microsoft partnership",  "delta": -0.0008, "default": False, "sign": "−"},
        {"text": "Sam Altman political spotlight / governance risk", "delta": -0.0005, "default": False, "sign": "−"},
    ],
    "SpaceX": [
        {"text": "Starship achieving full reuse milestones",        "delta": +0.0015, "default": True,  "sign": "+"},
        {"text": "Starlink subscriber growth accelerating",         "delta": +0.0020, "default": True,  "sign": "+"},
        {"text": "DoD + NASA contract pipeline expanding",          "delta": +0.0010, "default": True,  "sign": "+"},
        {"text": "Starlink partial IPO / value unlock rumored",     "delta": +0.0015, "default": False, "sign": "+"},
        {"text": "FAA launch license delays persisting",            "delta": -0.0015, "default": False, "sign": "−"},
        {"text": "Elon Musk brand risk (DOGE / political exposure)","delta": -0.0012, "default": True,  "sign": "−"},
        {"text": "Amazon Kuiper entering commercial service",       "delta": -0.0008, "default": False, "sign": "−"},
        {"text": "Starship cost overruns delaying timeline",        "delta": -0.0010, "default": False, "sign": "−"},
    ],
}

# ── Data helpers ──────────────────────────────────────────────────────────────────

@st.cache_data(ttl=3600, show_spinner=False)
def load_series(ticker: str, start: str) -> pd.Series:
    df = yf.download(ticker, start=start, auto_adjust=True, progress=False)
    if df.empty:
        return pd.Series(dtype=float)
    c = df["Close"]
    return (c.iloc[:, 0] if isinstance(c, pd.DataFrame) else c).dropna()

@st.cache_data(ttl=3600, show_spinner=False)
def load_comp(ticker: str, ipo_date: str, months: int) -> pd.Series:
    end = (pd.Timestamp(ipo_date) + pd.DateOffset(months=months)).strftime("%Y-%m-%d")
    df = yf.download(ticker, start=ipo_date, end=end, auto_adjust=True, progress=False)
    if df.empty:
        return pd.Series(dtype=float)
    c = df["Close"]
    return (c.iloc[:, 0] if isinstance(c, pd.DataFrame) else c).dropna()

def norm(s: pd.Series) -> pd.Series:
    return 100 * s / s.iloc[0] if not s.empty and s.iloc[0] != 0 else s

def run_mc(mu, sig, months, n=3000, start=100.0):
    rng = np.random.default_rng(42)
    shocks = rng.normal(mu - 0.5 * sig**2, sig, (months, n))
    return start * np.exp(np.cumsum(np.vstack([np.zeros(n), shocks]), axis=0))

def pct_bands(paths):
    return {p: np.percentile(paths, p, axis=1) for p in [5, 25, 50, 75, 95]}

def stat_card_html(name, color, ticker, total_ret, cagr, sector):
    sign = "+" if total_ret >= 0 else ""
    rc = "#00E676" if total_ret >= 0 else "#FF4B4B"
    return (f'<div class="stat-card">'
            f'<div class="stat-card-bar" style="background:{color};"></div>'
            f'<div class="stat-ticker">{ticker} · {sector}</div>'
            f'<div class="stat-company">{name}</div>'
            f'<div class="stat-return" style="color:{rc};">{sign}{total_ret:,.0f}%</div>'
            f'<div class="stat-label">total return since IPO</div>'
            f'<div class="stat-cagr">CAGR {cagr:.1f}%/yr</div>'
            f'</div>')

def adj_html(label, value_mo, source=""):
    """Render one row of the methodology breakdown."""
    ann = value_mo * 12 * 100
    if abs(ann) < 0.01:
        cls, txt = "adj-neu", "± 0.0%/yr"
    elif ann > 0:
        cls, txt = "adj-pos", f"+{ann:.2f}%/yr"
    else:
        cls, txt = "adj-neg", f"{ann:.2f}%/yr"
    src = f'<span style="color:#555;font-size:0.7rem;"> ({source})</span>' if source else ""
    return (f'<div class="method-row">'
            f'<span class="method-key">{label}{src}</span>'
            f'<span class="{cls}">{txt}</span>'
            f'</div>')

# ═══════════════════════════════════════════════════════════════════════════════
# SIDEBAR
# ═══════════════════════════════════════════════════════════════════════════════

with st.sidebar:
    st.markdown("## 📡 Dotcom IPO Tracker")
    st.markdown("---")

    # ── Tab 1 controls ─────────────────────────────────────────────────────────
    st.markdown('<div class="section-header">Companies (Tab 1)</div>', unsafe_allow_html=True)
    sel_companies = []
    for name, info in COMPANIES.items():
        if st.checkbox(f"**{name}**  `{info['ticker']}`", value=True, key=f"chk_{name}"):
            sel_companies.append(name)

    st.markdown("---")
    st.markdown('<div class="section-header">Chart Options (Tab 1)</div>', unsafe_allow_html=True)
    view_mode = st.radio("View", ["Grid", "Combined", "Spotlight"], index=0,
                          format_func=lambda v: {"Grid": "Grid (one per company)",
                                                  "Combined": "Combined (all on one chart)",
                                                  "Spotlight": "Spotlight (single deep-dive)"}[v])
    if view_mode == "Spotlight":
        focus_co = st.selectbox("Spotlight company", sel_companies or list(COMPANIES.keys()))
    x_mode = st.radio("X-axis", ["Calendar date", "Days since IPO"], horizontal=True)

    st.markdown("---")
    st.markdown('<div class="section-header">Event Filter (Tab 1)</div>', unsafe_allow_html=True)
    ev_types = {t: st.checkbox(f"{m['icon']} {t.capitalize()}", value=True)
                for t, m in TYPE_META.items()}
    active_types = {t for t, on in ev_types.items() if on}

    # ── Projection variables ────────────────────────────────────────────────────
    st.markdown("---")
    st.markdown('<div class="section-header">Projection Variables (Tab 2)</div>', unsafe_allow_html=True)
    st.caption("These control the OpenAI & SpaceX forward projections.")

    proj_cfg: dict[str, dict] = {}

    for ipo_name in ["OpenAI", "SpaceX"]:
        color = IPO_COMPS[ipo_name]["color"]
        with st.expander(f"⚙️ {ipo_name}", expanded=(ipo_name == "OpenAI")):

            # ── Comparable weights ───────────────────────────────────────────
            st.markdown("**Comparable Weights**")
            st.caption("How similar is this company to each comp? Higher weight = more influence on the projection.")
            raw_weights: dict[str, int] = {}
            for comp in IPO_COMPS[ipo_name]["comps"]:
                raw_weights[comp["ticker"]] = st.slider(
                    comp["name"], 0, 100, 25, step=5,
                    key=f"cw_{ipo_name}_{comp['ticker']}",
                )
            total_w = sum(raw_weights.values()) or 1
            norm_weights = {k: v / total_w for k, v in raw_weights.items()}

            # ── Market environment ───────────────────────────────────────────
            st.markdown("**Market Environment**")
            macro_choice = st.select_slider(
                "Macro conditions at IPO",
                options=MACRO_OPTIONS, value="Neutral",
                key=f"macro_{ipo_name}",
            )

            # ── Revenue growth vs comps ──────────────────────────────────────
            st.markdown("**Growth Expectations**")
            growth_choice = st.select_slider(
                "Revenue growth vs comps",
                options=GROWTH_OPTIONS, value="In line with comps",
                key=f"growth_{ipo_name}",
            )

            # ── IPO valuation ────────────────────────────────────────────────
            st.markdown("**IPO Pricing**")
            val_choice = st.select_slider(
                "Valuation at IPO",
                options=VALUATION_OPTIONS, value="Fair value",
                key=f"val_{ipo_name}",
            )

            # ── Volatility ───────────────────────────────────────────────────
            st.markdown("**Volatility Expectation**")
            vol_choice = st.select_slider(
                "Expected volatility",
                options=VOL_OPTIONS, value="Normal",
                key=f"vol_{ipo_name}",
            )

            # ── News & current events ────────────────────────────────────────
            st.markdown("**News & Current Events**")
            st.caption("Check items that reflect the current landscape. Each shifts the expected monthly return.")
            news_delta = 0.0
            for item in NEWS_ITEMS[ipo_name]:
                sign_color = "#00E676" if item["sign"] == "+" else "#FF4B4B"
                label = (f'{item["text"]} '
                         f'<span style="color:{sign_color};font-size:0.7rem;font-weight:700;">'
                         f'({item["sign"]}{abs(item["delta"]*12*100):.1f}%/yr)</span>')
                checked = st.checkbox(
                    item["text"],
                    value=item["default"],
                    key=f"news_{ipo_name}_{item['text'][:30]}",
                    help=f"Monthly return impact: {item['sign']}{abs(item['delta']*100):.3f}%/mo "
                         f"({item['sign']}{abs(item['delta']*1200):.1f}%/yr annualised)",
                )
                if checked:
                    news_delta += item["delta"]

            # ── Custom override ──────────────────────────────────────────────
            st.markdown("**Custom Sentiment**")
            custom_ann = st.slider(
                "Manual return adjustment (%/yr)",
                min_value=-15.0, max_value=15.0, value=0.0, step=0.5,
                key=f"custom_{ipo_name}",
                help="Override based on your own research. Directly shifts the annual expected return.",
            )

            proj_cfg[ipo_name] = {
                "norm_weights": norm_weights,
                "macro_adj":    MACRO_ADJ[macro_choice],
                "growth_adj":   GROWTH_ADJ[growth_choice],
                "val_adj":      VALUATION_ADJ[val_choice],
                "vol_mult":     VOL_MULT[vol_choice],
                "news_delta":   news_delta,
                "custom_delta": custom_ann / 100 / 12,
                "macro_label":  macro_choice,
                "growth_label": growth_choice,
                "val_label":    val_choice,
                "vol_label":    vol_choice,
            }

    st.markdown("---")
    st.caption("Price data: Yahoo Finance. Not investment advice.")

# ═══════════════════════════════════════════════════════════════════════════════
# Pre-load price data
# ═══════════════════════════════════════════════════════════════════════════════

if not sel_companies:
    st.warning("Select at least one company in the sidebar.")
    st.stop()

with st.spinner("Loading price data…"):
    all_data: dict[str, pd.Series] = {
        name: s
        for name in sel_companies
        if not (s := load_series(COMPANIES[name]["ticker"], COMPANIES[name]["ipo_date"])).empty
    }

tab1, tab2 = st.tabs(["📈  Dotcom IPO Performance", "🔮  OpenAI & SpaceX Projections"])

# ═══════════════════════════════════════════════════════════════════════════════
# TAB 1
# ═══════════════════════════════════════════════════════════════════════════════

with tab1:

    st.markdown('<div class="section-header">Company Overview</div>', unsafe_allow_html=True)
    card_cols = st.columns(len(sel_companies))
    for col, name in zip(card_cols, sel_companies):
        if name not in all_data:
            continue
        s = all_data[name]
        info = COMPANIES[name]
        total_ret = (s.iloc[-1] / s.iloc[0] - 1) * 100
        age_yr = max((s.index[-1] - s.index[0]).days / 365.25, 0.01)
        cagr = ((s.iloc[-1] / s.iloc[0]) ** (1 / age_yr) - 1) * 100
        col.markdown(stat_card_html(name, info["color"], info["ticker"], total_ret, cagr, info["sector"]),
                     unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown('<div class="section-header">Price History</div>', unsafe_allow_html=True)

    # ── GRID VIEW ──────────────────────────────────────────────────────────────
    if view_mode == "Grid":
        n = len(sel_companies)
        ncols = min(3, n)
        nrows = (n + ncols - 1) // ncols
        fig = make_subplots(
            rows=nrows, cols=ncols,
            subplot_titles=[f"<b>{nm}</b>  ({COMPANIES[nm]['ticker']})" for nm in sel_companies],
            vertical_spacing=0.18, horizontal_spacing=0.07,
        )
        for i, name in enumerate(sel_companies):
            if name not in all_data:
                continue
            r, c = divmod(i, ncols); r += 1; c += 1
            info = COMPANIES[name]
            s = all_data[name]; ns = norm(s)
            xs = list(range(len(ns))) if x_mode == "Days since IPO" else ns.index.tolist()

            if x_mode == "Calendar date":
                fig.add_vrect(x0="2000-03-10", x1="2002-10-09",
                              fillcolor="rgba(255,75,75,0.06)", line_width=0, row=r, col=c)

            fig.add_trace(go.Scatter(x=xs, y=ns.values, line=dict(color=info["color"], width=2),
                                      showlegend=False,
                                      hovertemplate=f"<b>{name}</b><br>%{{x}}<br>Indexed: %{{y:,.0f}}<extra></extra>"),
                          row=r, col=c)
            fig.add_hline(y=100, line_dash="dot", line_color="#444", line_width=1, row=r, col=c)

            for ev in EVENTS.get(name, []):
                if ev["type"] not in active_types:
                    continue
                ev_ts = pd.Timestamp(ev["date"])
                if ev_ts < s.index[0] or ev_ts > s.index[-1]:
                    continue
                idx_pos = min(ns.index.searchsorted(ev_ts), len(ns) - 1)
                ev_x = xs[idx_pos] if x_mode == "Days since IPO" else ns.index[idx_pos]
                meta = TYPE_META[ev["type"]]
                fig.add_trace(go.Scatter(
                    x=[ev_x], y=[float(ns.iloc[idx_pos])], mode="markers",
                    marker=dict(color=meta["color"], size=9, line=dict(width=1.5, color="#0e0e0e")),
                    showlegend=False,
                    hovertemplate=f"<b>{meta['icon']} {ev['label']}</b><br>{ev['desc']}<extra></extra>",
                ), row=r, col=c)

            fig.update_yaxes(type="log", tickvals=[1,10,100,1000,10000,100000],
                             ticktext=["1","10","100","1k","10k","100k"], row=r, col=c)

        fig.update_layout(template="plotly_dark", paper_bgcolor="#0e0e0e", plot_bgcolor="#111",
                          height=280*nrows, margin=dict(t=50, b=20, l=20, r=20), hovermode="closest")
        fig.update_annotations(font_size=12, font_color="#C8D6E5")
        st.plotly_chart(fig, width="stretch")

    # ── COMBINED VIEW ───────────────────────────────────────────────────────────
    elif view_mode == "Combined":
        fig = go.Figure()
        if x_mode == "Calendar date":
            fig.add_vrect(x0="2000-03-10", x1="2002-10-09",
                          fillcolor="rgba(255,75,75,0.06)", line_width=0,
                          annotation_text="Dotcom bust", annotation_position="top left",
                          annotation_font_color="#FF6B6B", annotation_font_size=10)
            for rs, re in [("2001-03-01","2001-11-30"),("2007-12-01","2009-06-30"),("2020-02-01","2020-04-30")]:
                fig.add_vrect(x0=rs, x1=re, fillcolor="rgba(150,150,150,0.04)", line_width=0)

        for name in sel_companies:
            if name not in all_data:
                continue
            info = COMPANIES[name]; s = all_data[name]; ns = norm(s)
            xs = list(range(len(ns))) if x_mode == "Days since IPO" else ns.index.tolist()
            fig.add_trace(go.Scatter(x=xs, y=ns.values, name=name,
                                      line=dict(color=info["color"], width=2.5),
                                      hovertemplate=f"<b>{name}</b><br>%{{x}}<br>Indexed: %{{y:,.0f}}<extra></extra>"))
            fig.add_annotation(x=xs[-1], y=float(ns.iloc[-1]), text=f"  {name}",
                               xanchor="left", yanchor="middle", showarrow=False,
                               font=dict(color=info["color"], size=10))

        fig.add_hline(y=100, line_dash="dot", line_color="#444", line_width=1)
        fig.update_layout(template="plotly_dark", paper_bgcolor="#0e0e0e", plot_bgcolor="#111",
                          height=520,
                          yaxis=dict(type="log", title="Indexed (IPO = 100)",
                                     tickvals=[1,10,100,1000,10000,100000],
                                     ticktext=["1","10","100","1k","10k","100k"]),
                          xaxis=dict(title="Days since IPO" if x_mode == "Days since IPO" else ""),
                          legend=dict(orientation="h", y=1.04, x=0),
                          margin=dict(t=40, b=20, r=130), hovermode="x unified")
        st.plotly_chart(fig, width="stretch")

    # ── SPOTLIGHT VIEW ──────────────────────────────────────────────────────────
    else:
        name = focus_co
        if name not in all_data:
            st.error(f"No data for {name}")
        else:
            info = COMPANIES[name]; s = all_data[name]; ns = norm(s)
            xs = list(range(len(ns))) if x_mode == "Days since IPO" else ns.index.tolist()
            fig = go.Figure()
            if x_mode == "Calendar date":
                fig.add_vrect(x0="2000-03-10", x1="2002-10-09",
                              fillcolor="rgba(255,75,75,0.07)", line_width=0)
            fig.add_trace(go.Scatter(x=xs, y=ns.values, line=dict(color=info["color"], width=2.5),
                                      showlegend=False,
                                      hovertemplate="Date: %{x}<br>Indexed: %{y:,.0f}<extra></extra>"))
            for ev in EVENTS.get(name, []):
                if ev["type"] not in active_types:
                    continue
                ev_ts = pd.Timestamp(ev["date"])
                if ev_ts < s.index[0] or ev_ts > s.index[-1]:
                    continue
                idx_pos = min(ns.index.searchsorted(ev_ts), len(ns) - 1)
                ev_x = xs[idx_pos] if x_mode == "Days since IPO" else ns.index[idx_pos]
                meta = TYPE_META[ev["type"]]
                fig.add_trace(go.Scatter(
                    x=[ev_x], y=[float(ns.iloc[idx_pos])], mode="markers+text",
                    marker=dict(color=meta["color"], size=10, line=dict(width=2, color="#0e0e0e")),
                    text=[ev["label"]], textposition="top center",
                    textfont=dict(size=9, color=meta["color"]),
                    showlegend=False,
                    hovertemplate=f"<b>{meta['icon']} {ev['label']}</b><br>{ev['desc']}<extra></extra>",
                ))
            fig.add_hline(y=100, line_dash="dot", line_color="#444", line_width=1)
            fig.update_layout(
                template="plotly_dark", paper_bgcolor="#0e0e0e", plot_bgcolor="#111", height=500,
                title=dict(text=f"<b>{name}</b> — Full History", font=dict(color=info["color"], size=16)),
                yaxis=dict(type="log", title="Indexed (IPO = 100)",
                           tickvals=[1,10,100,1000,10000,100000],
                           ticktext=["1","10","100","1k","10k","100k"]),
                xaxis=dict(title="Days since IPO" if x_mode == "Days since IPO" else ""),
                margin=dict(t=50, b=20), hovermode="closest",
            )
            st.plotly_chart(fig, width="stretch")

    # ── Event timeline ────────────────────────────────────────────────────────
    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown('<div class="section-header">Event Timeline</div>', unsafe_allow_html=True)
    timeline = sorted(
        [{**ev, "company": name} for name in sel_companies for ev in EVENTS.get(name, []) if ev["type"] in active_types],
        key=lambda e: e["date"],
    )
    if not timeline:
        st.caption("No events match the current filter.")
    else:
        ev_cols = st.columns(3)
        for i, ev in enumerate(timeline):
            meta = TYPE_META[ev["type"]]
            co_color = COMPANIES[ev["company"]]["color"]
            with ev_cols[i % 3]:
                st.markdown(
                    f'<div class="ev-block" style="border-top:3px solid {meta["color"]};">'
                    f'<span class="ev-date">{ev["date"]}</span>'
                    f'<span style="float:right;font-size:0.7rem;color:{co_color};">{ev["company"]}</span>'
                    f'<div class="ev-label" style="color:{meta["color"]};">{meta["icon"]} {ev["label"]}</div>'
                    f'<div class="ev-desc">{ev["desc"]}</div></div>',
                    unsafe_allow_html=True,
                )

    # ── Performance table ─────────────────────────────────────────────────────
    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown('<div class="section-header">Performance Summary</div>', unsafe_allow_html=True)
    rows = []
    for name in sel_companies:
        if name not in all_data:
            continue
        s = all_data[name]; info = COMPANIES[name]
        total_ret = (s.iloc[-1] / s.iloc[0] - 1) * 100
        age_yr = max((s.index[-1] - s.index[0]).days / 365.25, 0.01)
        cagr = ((s.iloc[-1] / s.iloc[0]) ** (1 / age_yr) - 1) * 100
        dd = ((s - s.cummax()) / s.cummax()).min() * 100
        rows.append({"Company": name, "Ticker": info["ticker"], "Sector": info["sector"],
                     "IPO Date": info["ipo_date"], "Total Return": f"{total_ret:+,.0f}%",
                     "CAGR": f"{cagr:.1f}%/yr", "Max Drawdown": f"{dd:.1f}%",
                     "Current Index": f"{norm(s).iloc[-1]:,.0f}"})
    if rows:
        st.dataframe(pd.DataFrame(rows).set_index("Company"), width="stretch")

# ═══════════════════════════════════════════════════════════════════════════════
# TAB 2
# ═══════════════════════════════════════════════════════════════════════════════

with tab2:
    st.markdown("# OpenAI & SpaceX — IPO Projections")
    st.markdown(
        "Projections combine **historical comparable post-IPO statistics** with the "
        "**adjustment variables you set in the sidebar** (market environment, growth expectations, "
        "IPO valuation, news sentiment). Each variable is shown explicitly in the methodology panel."
    )

    horizon_mo = st.slider("Projection horizon (months)", 12, 84, 60, key="horizon")

    for ipo_name in ["OpenAI", "SpaceX"]:
        cfg = IPO_COMPS[ipo_name]
        p = proj_cfg[ipo_name]
        color = cfg["color"]
        r_hex, g_hex, b_hex = int(color[1:3], 16), int(color[3:5], 16), int(color[5:7], 16)

        st.markdown("---")

        # Company header
        st.markdown(
            f'<div style="background:#0f1117;border:1px solid #2a2a2a;border-left:4px solid {color};'
            f'border-radius:8px;padding:12px 18px;margin-bottom:16px;">'
            f'<span style="font-size:1.25rem;font-weight:800;color:{color};">{ipo_name}</span>'
            f'<span style="font-size:0.82rem;color:#9CA3AF;margin-left:12px;">{cfg["desc"]}</span>'
            f'</div>',
            unsafe_allow_html=True,
        )

        chart_col, info_col = st.columns([6, 4], gap="large")

        with chart_col:

            # ── Load comp data and compute weighted base stats ────────────────
            comp_monthly: dict[str, list[float]] = {}
            comp_series: dict[str, pd.Series] = {}

            for comp in cfg["comps"]:
                s = load_comp(comp["ticker"], comp["ipo_date"], months=horizon_mo)
                if s.empty:
                    continue
                comp_series[comp["ticker"]] = s
                monthly = (s.pct_change().dropna()
                            .resample("ME")
                            .apply(lambda x: (1 + x).prod() - 1)
                            .dropna())
                comp_monthly[comp["ticker"]] = monthly.tolist()

            # Weighted base mu = sum(weight_i * mean_i)
            base_mu = 0.0
            base_sig_pool: list[float] = []
            for comp in cfg["comps"]:
                tk = comp["ticker"]
                if tk not in comp_monthly:
                    continue
                w = p["norm_weights"].get(tk, 0.0)
                base_mu += w * float(np.mean(comp_monthly[tk]))
                base_sig_pool.extend(comp_monthly[tk])

            base_sig = float(np.std(base_sig_pool)) if base_sig_pool else 0.05

            # Apply adjustments
            total_adj = p["macro_adj"] + p["growth_adj"] + p["val_adj"] + p["news_delta"] + p["custom_delta"]
            eff_mu  = base_mu + total_adj
            eff_sig = base_sig * p["vol_mult"]

            # Run Monte Carlo
            paths = run_mc(eff_mu, eff_sig, horizon_mo)
            b = pct_bands(paths)
            xp = list(range(horizon_mo + 1))

            fig_p = go.Figure()

            # Comp lines (dotted)
            for comp in cfg["comps"]:
                tk = comp["ticker"]
                if tk not in comp_series:
                    continue
                c_norm = norm(comp_series[tk])
                c_color = COMP_COLORS.get(tk, "#666")
                w = p["norm_weights"].get(tk, 0.0)
                opacity = max(0.2, min(0.85, 0.3 + w * 0.8))
                fig_p.add_trace(go.Scatter(
                    x=list(range(len(c_norm))), y=c_norm.values,
                    name=f"{comp['name']} (w={w:.0%})",
                    line=dict(color=c_color, width=1.5, dash="dot"),
                    opacity=opacity,
                    hovertemplate=f"<b>{comp['name']}</b><br>Month %{{x}}: %{{y:,.0f}}<extra></extra>",
                ))

            # Monte Carlo fan
            for lo, hi, alpha in [(5, 25, 0.07), (25, 75, 0.18), (75, 95, 0.07)]:
                fig_p.add_trace(go.Scatter(
                    x=xp + xp[::-1],
                    y=list(b[hi]) + list(b[lo])[::-1],
                    fill="toself",
                    fillcolor=f"rgba({r_hex},{g_hex},{b_hex},{alpha})",
                    line=dict(width=0), showlegend=False, hoverinfo="skip",
                ))
            fig_p.add_trace(go.Scatter(
                x=xp, y=b[50],
                line=dict(color=color, width=3),
                name=f"{ipo_name} — median projection",
            ))
            for pct, dash in [(5, "dash"), (95, "dash")]:
                fig_p.add_trace(go.Scatter(
                    x=xp, y=b[pct],
                    line=dict(color=color, width=1, dash=dash),
                    showlegend=False, hoverinfo="skip",
                ))

            fig_p.add_hline(y=100, line_dash="dot", line_color="#444", line_width=1)
            fig_p.update_layout(
                template="plotly_dark", paper_bgcolor="#0e0e0e", plot_bgcolor="#111",
                height=380,
                xaxis=dict(title="Months after IPO"),
                yaxis=dict(type="log", title="Indexed (IPO = 100)",
                           tickvals=[10,50,100,500,1000,5000,20000],
                           ticktext=["10","50","100","500","1k","5k","20k"]),
                legend=dict(font=dict(size=9), orientation="h", y=1.04),
                margin=dict(t=10, b=30),
            )
            st.plotly_chart(fig_p, width="stretch")

            # Outcome metrics
            m1, m2, m3, m4 = st.columns(4)
            m1.metric("Median outcome",  f"{b[50][-1]:.0f}×",  "vs IPO price")
            m2.metric("Bull case (p95)", f"{b[95][-1]:.0f}×")
            m3.metric("Bear case (p5)",  f"{b[5][-1]:.0f}×")
            prob_2x = (paths[-1] > 200).mean() * 100
            m4.metric("Prob. 2× IPO",   f"{prob_2x:.0f}%")

        with info_col:

            # ── Methodology breakdown ─────────────────────────────────────────
            st.markdown('<div class="section-header">How this projection is built</div>', unsafe_allow_html=True)

            method_html = '<div class="method-box">'
            method_html += '<div style="color:#9CA3AF;font-size:0.72rem;margin-bottom:8px;">MODEL: Geometric Brownian Motion Monte Carlo · 3,000 paths</div>'

            method_html += '<div style="color:#6B7280;font-size:0.68rem;font-weight:700;letter-spacing:0.08em;margin-bottom:4px;">BASE (from comp data)</div>'
            method_html += adj_html("Weighted comp mean return", base_mu,
                                     f"{', '.join(c['name'] for c in cfg['comps'] if c['ticker'] in comp_series)}")

            method_html += '<div style="color:#6B7280;font-size:0.68rem;font-weight:700;letter-spacing:0.08em;margin:8px 0 4px;">ADJUSTMENTS (your sidebar settings)</div>'
            method_html += adj_html(f"Market environment  ({p['macro_label']})",  p["macro_adj"])
            method_html += adj_html(f"Growth vs comps  ({p['growth_label']})",     p["growth_adj"])
            method_html += adj_html(f"IPO valuation  ({p['val_label']})",           p["val_adj"])

            # News breakdown
            total_news_shown = p["news_delta"] + p["custom_delta"]
            method_html += adj_html(f"News & sentiment  ({p['news_delta']*1200:+.1f}%/yr from events)", p["news_delta"])
            if abs(p["custom_delta"]) > 0.0001:
                method_html += adj_html("Custom manual adjustment", p["custom_delta"])

            # Effective totals
            method_html += (
                f'<div class="method-total">'
                f'<span>Effective μ</span>'
                f'<span style="color:#F0F0F0;">{eff_mu*100:.3f}%/mo  ≈  {eff_mu*1200:.1f}%/yr</span>'
                f'</div>'
                f'<div class="method-total">'
                f'<span>Effective σ  ({p["vol_label"]})</span>'
                f'<span style="color:#F0F0F0;">{eff_sig*100:.2f}%/mo  ≈  {eff_sig*100*(12**0.5):.1f}%/yr</span>'
                f'</div>'
            )
            method_html += '</div>'
            st.markdown(method_html, unsafe_allow_html=True)

            # ── Comp weight display ───────────────────────────────────────────
            st.markdown('<div class="section-header">Comparable Weights Applied</div>', unsafe_allow_html=True)
            for comp in cfg["comps"]:
                tk = comp["ticker"]
                w = p["norm_weights"].get(tk, 0.0)
                bar_w = int(w * 100)
                c_color = COMP_COLORS.get(tk, "#888")
                mn = float(np.mean(comp_monthly[tk])) * 1200 if tk in comp_monthly else 0
                st.markdown(
                    f'<div style="margin-bottom:8px;">'
                    f'<div style="display:flex;justify-content:space-between;font-size:0.78rem;">'
                    f'<span style="color:{c_color};font-weight:600;">{comp["name"]}</span>'
                    f'<span style="color:#9CA3AF;">{w:.0%} weight · {mn:+.1f}%/yr hist.</span>'
                    f'</div>'
                    f'<div style="background:#2a2a2a;border-radius:4px;height:5px;margin-top:4px;">'
                    f'<div style="background:{c_color};width:{bar_w}%;height:5px;border-radius:4px;"></div>'
                    f'</div></div>',
                    unsafe_allow_html=True,
                )

            # ── Active news items ─────────────────────────────────────────────
            st.markdown('<div class="section-header" style="margin-top:14px;">Active News Factors</div>', unsafe_allow_html=True)
            any_active = False
            for item in NEWS_ITEMS[ipo_name]:
                key = f"news_{ipo_name}_{item['text'][:30]}"
                if st.session_state.get(key, item["default"]):
                    any_active = True
                    ann_impact = item["delta"] * 1200
                    sign_color = "#00E676" if item["sign"] == "+" else "#FF4B4B"
                    st.markdown(
                        f'<div style="font-size:0.76rem;color:#C8D6E5;padding:3px 0;display:flex;justify-content:space-between;">'
                        f'<span>{"✅" if item["sign"]=="+" else "⚠️"} {item["text"]}</span>'
                        f'<span style="color:{sign_color};font-weight:700;white-space:nowrap;margin-left:8px;">'
                        f'{item["sign"]}{abs(ann_impact):.1f}%/yr</span>'
                        f'</div>',
                        unsafe_allow_html=True,
                    )
            if not any_active:
                st.caption("No news factors currently active.")

    # ── All comps combined ────────────────────────────────────────────────────
    st.markdown("---")
    st.markdown('<div class="section-header">All Comparables — Overlaid (Months Since IPO)</div>', unsafe_allow_html=True)
    st.caption("Every comparable from both OpenAI and SpaceX, normalized to 100 at their IPO date.")

    fig_all = go.Figure()
    for ipo_name, cfg in IPO_COMPS.items():
        for comp in cfg["comps"]:
            s = load_comp(comp["ticker"], comp["ipo_date"], months=60)
            if s.empty:
                continue
            ns = norm(s)
            c_color = COMP_COLORS.get(comp["ticker"], "#888")
            fig_all.add_trace(go.Scatter(
                x=list(range(len(ns))), y=ns.values,
                name=f"{comp['name']}  ({ipo_name})",
                line=dict(color=c_color, width=2),
                hovertemplate=f"<b>{comp['name']}</b><br>Month %{{x}}: %{{y:,.0f}}<extra></extra>",
            ))
    fig_all.add_hline(y=100, line_dash="dot", line_color="#444", line_width=1)
    fig_all.update_layout(
        template="plotly_dark", paper_bgcolor="#0e0e0e", plot_bgcolor="#111", height=400,
        xaxis=dict(title="Months after IPO"),
        yaxis=dict(type="log", title="Indexed (IPO = 100)",
                   tickvals=[10,50,100,500,1000,5000,20000],
                   ticktext=["10","50","100","500","1k","5k","20k"]),
        legend=dict(font=dict(size=9), orientation="h", y=1.06),
        margin=dict(t=10, b=20),
    )
    st.plotly_chart(fig_all, width="stretch")
    st.caption("OpenAI and SpaceX remain private. Projections are illustrative only and do not constitute investment advice.")
