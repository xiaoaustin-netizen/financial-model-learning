import streamlit as st
import yfinance as yf
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from datetime import datetime, timedelta
import warnings

warnings.filterwarnings("ignore")

st.set_page_config(page_title="Rare Minerals Simulator", layout="wide", page_icon="🪙")

st.markdown("""
<style>
    body { background-color: #0e0e0e; }
    .block-container { padding-top: 1.5rem; }
    h1 { color: #FFD700; font-size: 2.2rem; }
    h2, h3 { color: #E8D48B; }
    .stMetric label { color: #aaa; }
    .stMetric [data-testid="metric-container"] { background: #1a1a1a; border-radius: 8px; padding: 0.5rem 1rem; border: 1px solid #333; }
    div[data-testid="stSidebarContent"] { background: #111; }
</style>
""", unsafe_allow_html=True)

# ── Historical crisis events (for chart annotations and stats computation) ──────

EVENTS = {
    "Geopolitical Conflict": [
        {"name": "Iraq War",            "start": "2003-03-20", "end": "2004-01-01"},
        {"name": "2008 GFC",            "start": "2008-09-01", "end": "2009-06-30"},
        {"name": "COVID Crash",         "start": "2020-02-01", "end": "2020-12-31"},
        {"name": "Russia-Ukraine",      "start": "2022-02-24", "end": "2023-06-01"},
    ],
    "High Inflation": [
        {"name": "2011 Debt Crisis",    "start": "2011-01-01", "end": "2012-06-30"},
        {"name": "2021-23 Inflation",   "start": "2021-01-01", "end": "2023-06-01"},
    ],
}

# Pre-GLD historical context (gold spot price USD/oz, annualized)
HISTORICAL_CONTEXT = {
    "Geopolitical Conflict": {
        "Gulf War 1990-91":   {"gold_ann": 8,    "sp500_ann": -3,   "duration_mo": 7},
        "9/11 Aftermath":     {"gold_ann": 24,   "sp500_ann": -22,  "duration_mo": 12},
    },
    "High Inflation": {
        "1970s Stagflation":  {"gold_ann": 31,   "sp500_ann": 3,    "duration_mo": 84},
        "1979-80 Gold Spike": {"gold_ann": 126,  "sp500_ann": 18,   "duration_mo": 18},
    },
}

SCENARIO_COLORS = {
    "Geopolitical Conflict": "#FF8C00",
    "High Inflation":        "#FF4B4B",
    "Baseline":              "#4ECDC4",
}

# ── Data loading ────────────────────────────────────────────────────────────────

@st.cache_data(ttl=3600, show_spinner="Fetching market data…")
def load_data():
    raw = yf.download(["GLD", "SPY"], start="2004-01-01", auto_adjust=True, progress=False)
    close = raw["Close"] if "Close" in raw.columns else raw.xs("Close", axis=1, level=0)
    close = close.dropna()
    return close

def monthly_returns(series: pd.Series) -> pd.Series:
    return series.resample("ME").last().pct_change().dropna()

def compute_scenario_stats(data: pd.DataFrame, events: list[dict]) -> dict:
    """Return (mean_monthly_ret, monthly_vol) for GLD and SPY across crisis windows."""
    gold_rets, spy_rets = [], []
    for ev in events:
        s, e = ev["start"], ev["end"]
        if s < data.index[0].strftime("%Y-%m-%d"):
            continue
        window = data.loc[s:e]
        if len(window) < 5:
            continue
        gold_rets.extend(monthly_returns(window["GLD"]).tolist())
        spy_rets.extend(monthly_returns(window["SPY"]).tolist())
    if not gold_rets:
        return None
    return {
        "gold_mu":  float(np.mean(gold_rets)),
        "gold_sig": float(np.std(gold_rets)),
        "spy_mu":   float(np.mean(spy_rets)),
        "spy_sig":  float(np.std(spy_rets)),
        "n_months": len(gold_rets),
    }

# Fallback params derived from literature / historical records
FALLBACK_PARAMS = {
    "Geopolitical Conflict": {"gold_mu": 0.0125, "gold_sig": 0.042, "spy_mu": 0.003, "spy_sig": 0.058},
    "High Inflation":        {"gold_mu": 0.0190, "gold_sig": 0.048, "spy_mu": 0.002, "spy_sig": 0.062},
    "Baseline":              {"gold_mu": 0.0040, "gold_sig": 0.028, "spy_mu": 0.011, "spy_sig": 0.040},
}

# ── Monte Carlo engine ───────────────────────────────────────────────────────────

def run_monte_carlo(mu: float, sigma: float, months: int = 60, n_paths: int = 2000, start: float = 100.0) -> np.ndarray:
    """Return (months+1, n_paths) array of price paths."""
    rng = np.random.default_rng(42)
    shocks = rng.normal(mu - 0.5 * sigma**2, sigma, (months, n_paths))
    log_returns = np.vstack([np.zeros(n_paths), shocks])
    return start * np.exp(np.cumsum(log_returns, axis=0))

def percentile_bands(paths: np.ndarray) -> dict:
    pcts = [5, 25, 50, 75, 95]
    return {p: np.percentile(paths, p, axis=1) for p in pcts}

# ── Chart helpers ────────────────────────────────────────────────────────────────

BAND_FILLS = [(5, 25, "rgba(255,215,0,0.08)"), (25, 75, "rgba(255,215,0,0.18)"), (75, 95, "rgba(255,215,0,0.08)")]

def add_mc_fan(fig: go.Figure, bands: dict, months: int, label: str, color: str, row=1, col=1):
    x = list(range(months + 1))
    for lo, hi, fill in BAND_FILLS:
        fig.add_trace(go.Scatter(
            x=x + x[::-1],
            y=list(bands[hi]) + list(bands[lo])[::-1],
            fill="toself", fillcolor=fill,
            line=dict(width=0), showlegend=False, hoverinfo="skip",
        ), row=row, col=col)
    fig.add_trace(go.Scatter(
        x=x, y=bands[50],
        line=dict(color=color, width=2.5),
        name=f"{label} median",
    ), row=row, col=col)
    for p, dash in [(25, "dot"), (75, "dot"), (5, "dash"), (95, "dash")]:
        fig.add_trace(go.Scatter(
            x=x, y=bands[p],
            line=dict(color=color, width=1, dash=dash),
            name=f"{label} p{p}", showlegend=False, hoverinfo="skip",
        ), row=row, col=col)

# ── Sidebar ──────────────────────────────────────────────────────────────────────

with st.sidebar:
    st.markdown("## ⚙️ Settings")
    investment = st.number_input("Starting investment ($)", min_value=1_000, max_value=10_000_000,
                                  value=10_000, step=1_000, format="%d")
    scenario = st.selectbox("Scenario", ["Geopolitical Conflict", "High Inflation", "Baseline"])
    horizon_yr = st.slider("Projection horizon (years)", 1, 10, 5)
    n_paths = st.select_slider("Simulation paths", [500, 1000, 2000, 5000], value=2000)
    st.markdown("---")
    st.markdown("**About**")
    st.caption(
        "Historical data via Yahoo Finance (GLD / SPY). "
        "Pre-2004 statistics sourced from World Gold Council archives. "
        "Projections use geometric Brownian motion Monte Carlo."
    )

# ── Main ─────────────────────────────────────────────────────────────────────────

st.markdown("# 🪙 Rare Minerals Market Simulator")
st.markdown(
    "Explore how **gold** has historically outperformed the broader market during periods of uncertainty, "
    "and project forward using scenario-based Monte Carlo simulations."
)

data = load_data()
horizon_mo = horizon_yr * 12

# Compute scenario stats from real data
if scenario != "Baseline":
    computed = compute_scenario_stats(data, EVENTS[scenario])
else:
    computed = None

params = computed if computed else FALLBACK_PARAMS[scenario]

tab1, tab2, tab3 = st.tabs(["📈 Historical Performance", "🔮 5-Year Projection", "📊 Scenario Comparison"])

# ═══════════════════════════════════════════════════════════════════════════════
# TAB 1 – Historical Performance
# ═══════════════════════════════════════════════════════════════════════════════

with tab1:
    st.markdown(f"### Gold vs. S&P 500 — *{scenario}* Periods (2004–Present)")
    st.caption("Each crisis window is rebased to 100 at its start date so you can compare relative performance.")

    events_to_show = EVENTS.get(scenario, [])

    if not events_to_show:
        st.info("Select 'Geopolitical Conflict' or 'High Inflation' to see historical crisis windows.")
    else:
        # Build subplots – one per event
        n_cols = 2
        n_rows = (len(events_to_show) + 1) // n_cols
        subplot_titles = [ev["name"] for ev in events_to_show]
        fig_hist = make_subplots(rows=n_rows, cols=n_cols, subplot_titles=subplot_titles,
                                  shared_xaxes=False, vertical_spacing=0.14, horizontal_spacing=0.08)

        for idx, ev in enumerate(events_to_show):
            r, c = divmod(idx, n_cols)
            row, col = r + 1, c + 1
            s, e = ev["start"], ev["end"]
            # Clip to available data
            s = max(s, data.index[0].strftime("%Y-%m-%d"))
            window = data.loc[s:e].copy()
            if len(window) < 3:
                continue
            rebased = 100 * window / window.iloc[0]
            fig_hist.add_trace(go.Scatter(x=rebased.index, y=rebased["GLD"],
                                           line=dict(color="#FFD700", width=2),
                                           name="Gold (GLD)" if idx == 0 else "Gold (GLD)",
                                           showlegend=(idx == 0)), row=row, col=col)
            fig_hist.add_trace(go.Scatter(x=rebased.index, y=rebased["SPY"],
                                           line=dict(color="#7CB9E8", width=2, dash="dot"),
                                           name="S&P 500 (SPY)" if idx == 0 else "S&P 500 (SPY)",
                                           showlegend=(idx == 0)), row=row, col=col)
            fig_hist.add_hline(y=100, line_width=1, line_dash="dash", line_color="gray",
                                row=row, col=col)

        fig_hist.update_layout(
            height=350 * n_rows, template="plotly_dark",
            paper_bgcolor="#0e0e0e", plot_bgcolor="#131313",
            legend=dict(orientation="h", y=1.02, x=0),
            margin=dict(t=60, b=20),
        )
        fig_hist.update_yaxes(ticksuffix="", title_text="Indexed (start=100)")
        st.plotly_chart(fig_hist, width="stretch")

    # Key metrics across all crisis windows
    st.markdown("#### Key Metrics Across All Crisis Windows")
    metrics_rows = []
    for ev in events_to_show:
        s, e = ev["start"], ev["end"]
        s = max(s, data.index[0].strftime("%Y-%m-%d"))
        window = data.loc[s:e]
        if len(window) < 5:
            continue
        gold_ret = (window["GLD"].iloc[-1] / window["GLD"].iloc[0] - 1) * 100
        spy_ret  = (window["SPY"].iloc[-1] / window["SPY"].iloc[0] - 1) * 100
        duration = (pd.Timestamp(e) - pd.Timestamp(s)).days // 30
        metrics_rows.append({
            "Event": ev["name"],
            "Duration": f"{duration} mo",
            "Gold Return": f"{gold_ret:+.1f}%",
            "S&P 500 Return": f"{spy_ret:+.1f}%",
            "Gold Premium": f"{gold_ret - spy_ret:+.1f}pp",
        })

    if metrics_rows:
        df_m = pd.DataFrame(metrics_rows)
        st.dataframe(df_m.set_index("Event"), width="stretch")

    # Historical context (pre-2004)
    if scenario in HISTORICAL_CONTEXT:
        st.markdown("#### Pre-2004 Historical Reference")
        ctx_rows = []
        for name, vals in HISTORICAL_CONTEXT[scenario].items():
            ctx_rows.append({
                "Period": name,
                "Avg Annual Gold Return": f"{vals['gold_ann']:+d}%",
                "Avg Annual S&P 500 Return": f"{vals['sp500_ann']:+d}%",
                "Duration": f"{vals['duration_mo']} months",
            })
        st.dataframe(pd.DataFrame(ctx_rows).set_index("Period"), width="stretch")
        st.caption("Pre-2004 data uses World Gold Council gold spot price records.")

# ═══════════════════════════════════════════════════════════════════════════════
# TAB 2 – 5-Year Projection
# ═══════════════════════════════════════════════════════════════════════════════

with tab2:
    st.markdown(f"### {horizon_yr}-Year Projection — *{scenario}* Scenario")
    st.caption(
        f"Monte Carlo ({n_paths:,} paths) using historical monthly return statistics "
        f"computed from real crisis data. Starting value: **${investment:,.0f}**."
    )

    gold_mu  = params["gold_mu"]
    gold_sig = params["gold_sig"]
    spy_mu   = params["spy_mu"]
    spy_sig  = params["spy_sig"]

    gold_paths = run_monte_carlo(gold_mu, gold_sig, horizon_mo, n_paths, investment)
    spy_paths  = run_monte_carlo(spy_mu,  spy_sig,  horizon_mo, n_paths, investment)

    gold_bands = percentile_bands(gold_paths)
    spy_bands  = percentile_bands(spy_paths)

    fig_proj = go.Figure()
    x = list(range(horizon_mo + 1))

    # SPY fan
    for lo, hi, fill in [(5, 25, "rgba(124,185,232,0.07)"), (25, 75, "rgba(124,185,232,0.15)"), (75, 95, "rgba(124,185,232,0.07)")]:
        fig_proj.add_trace(go.Scatter(
            x=x + x[::-1], y=list(spy_bands[hi]) + list(spy_bands[lo])[::-1],
            fill="toself", fillcolor=fill, line=dict(width=0), showlegend=False, hoverinfo="skip",
        ))
    fig_proj.add_trace(go.Scatter(x=x, y=spy_bands[50], line=dict(color="#7CB9E8", width=2, dash="dash"),
                                   name="S&P 500 median"))

    # Gold fan
    for lo, hi, fill in BAND_FILLS:
        fig_proj.add_trace(go.Scatter(
            x=x + x[::-1], y=list(gold_bands[hi]) + list(gold_bands[lo])[::-1],
            fill="toself", fillcolor=fill, line=dict(width=0), showlegend=False, hoverinfo="skip",
        ))
    fig_proj.add_trace(go.Scatter(x=x, y=gold_bands[50], line=dict(color="#FFD700", width=2.5),
                                   name="Gold median"))
    for p, dash in [(5, "dash"), (25, "dot"), (75, "dot"), (95, "dash")]:
        lbl = f"p{p}" if p in (5, 95) else None
        fig_proj.add_trace(go.Scatter(
            x=x, y=gold_bands[p],
            line=dict(color="#FFD700", width=1, dash=dash),
            name=lbl or f"Gold p{p}", showlegend=(lbl is not None),
        ))

    # X-axis: month labels as "Y1", "Y2" etc.
    xtick_vals = list(range(0, horizon_mo + 1, 12))
    xtick_text = [f"Y{i//12}" if i > 0 else "Now" for i in xtick_vals]

    fig_proj.update_layout(
        template="plotly_dark", paper_bgcolor="#0e0e0e", plot_bgcolor="#131313",
        height=480,
        xaxis=dict(tickvals=xtick_vals, ticktext=xtick_text, title=""),
        yaxis=dict(title="Portfolio Value ($)", tickformat="$,.0f"),
        legend=dict(orientation="h", y=1.02, x=0),
        margin=dict(t=40, b=20),
        hovermode="x unified",
    )
    # Shade probability annotation
    fig_proj.add_annotation(
        x=horizon_mo * 0.97, y=gold_bands[95][-1],
        text="90% probability band", showarrow=False,
        font=dict(color="#FFD700", size=11), xanchor="right",
    )
    st.plotly_chart(fig_proj, width="stretch")

    # Summary metrics
    final_gold = gold_bands[50][-1]
    final_spy  = spy_bands[50][-1]
    gold_upside = gold_bands[95][-1]
    gold_down   = gold_bands[5][-1]
    gold_ann_ret = (final_gold / investment) ** (1 / horizon_yr) - 1

    col1, col2, col3, col4, col5 = st.columns(5)
    col1.metric("Gold — Median Final", f"${final_gold:,.0f}", f"{(final_gold/investment - 1)*100:+.1f}%")
    col2.metric("S&P 500 — Median Final", f"${final_spy:,.0f}", f"{(final_spy/investment - 1)*100:+.1f}%")
    col3.metric("Gold — Best Case (p95)", f"${gold_upside:,.0f}")
    col4.metric("Gold — Worst Case (p5)", f"${gold_down:,.0f}")
    col5.metric("Gold CAGR (median)", f"{gold_ann_ret*100:.1f}%")

    st.markdown("---")
    col_p, col_s = st.columns(2)
    with col_p:
        st.markdown("**Parameters used for this projection**")
        st.caption(f"Source: {'Computed from {0} months of real crisis data'.format(params.get('n_months','')) if computed else 'Historical literature (pre-2004 records)'}")
        st.dataframe(pd.DataFrame({
            "Asset": ["Gold", "S&P 500"],
            "Monthly Return (μ)": [f"{gold_mu*100:.2f}%", f"{spy_mu*100:.2f}%"],
            "Monthly Volatility (σ)": [f"{gold_sig*100:.2f}%", f"{spy_sig*100:.2f}%"],
            "Annualised Return": [f"{((1+gold_mu)**12-1)*100:.1f}%", f"{((1+spy_mu)**12-1)*100:.1f}%"],
        }).set_index("Asset"), width="stretch")
    with col_s:
        # Probability analysis
        prob_beat_spy  = (gold_paths[-1] > spy_paths[-1]).mean() * 100
        prob_double    = (gold_paths[-1] > investment * 2).mean() * 100
        prob_loss      = (gold_paths[-1] < investment).mean() * 100
        st.markdown("**Probability Analysis**")
        st.dataframe(pd.DataFrame({
            "Outcome": [
                "Gold beats S&P 500",
                f"Gold doubles (>{investment*2:,.0f})",
                "Gold ends below entry",
            ],
            "Probability": [f"{prob_beat_spy:.0f}%", f"{prob_double:.0f}%", f"{prob_loss:.0f}%"],
        }).set_index("Outcome"), width="stretch")

# ═══════════════════════════════════════════════════════════════════════════════
# TAB 3 – Scenario Comparison
# ═══════════════════════════════════════════════════════════════════════════════

with tab3:
    st.markdown("### All-Scenario Comparison")
    st.caption(f"Gold median projection for all three scenarios over {horizon_yr} years. Starting: **${investment:,.0f}**.")

    fig_comp = go.Figure()
    all_scenario_rows = []

    for sc_name, color in SCENARIO_COLORS.items():
        if sc_name == "Baseline":
            p = FALLBACK_PARAMS["Baseline"]
        else:
            comp = compute_scenario_stats(data, EVENTS.get(sc_name, []))
            p = comp if comp else FALLBACK_PARAMS[sc_name]

        paths = run_monte_carlo(p["gold_mu"], p["gold_sig"], horizon_mo, n_paths, investment)
        bands = percentile_bands(paths)

        for lo, hi, alpha in [(5, 25, 0.07), (25, 75, 0.14), (75, 95, 0.07)]:
            r, g, b = int(color[1:3], 16), int(color[3:5], 16), int(color[5:7], 16)
            fill = f"rgba({r},{g},{b},{alpha})"
            fig_comp.add_trace(go.Scatter(
                x=x + x[::-1], y=list(bands[hi]) + list(bands[lo])[::-1],
                fill="toself", fillcolor=fill, line=dict(width=0), showlegend=False, hoverinfo="skip",
            ))
        fig_comp.add_trace(go.Scatter(
            x=x, y=bands[50], line=dict(color=color, width=2.5), name=f"Gold — {sc_name}",
        ))

        final = bands[50][-1]
        cagr = (final / investment) ** (1 / horizon_yr) - 1
        all_scenario_rows.append({
            "Scenario": sc_name,
            "Median Final Value": f"${final:,.0f}",
            "Total Return": f"{(final/investment - 1)*100:+.0f}%",
            f"CAGR ({horizon_yr}yr)": f"{cagr*100:.1f}%",
            "Best Case (p95)": f"${bands[95][-1]:,.0f}",
            "Worst Case (p5)": f"${bands[5][-1]:,.0f}",
        })

    fig_comp.update_layout(
        template="plotly_dark", paper_bgcolor="#0e0e0e", plot_bgcolor="#131313",
        height=480,
        xaxis=dict(tickvals=xtick_vals, ticktext=xtick_text, title=""),
        yaxis=dict(title="Portfolio Value ($)", tickformat="$,.0f"),
        legend=dict(orientation="h", y=1.02),
        margin=dict(t=40, b=20),
        hovermode="x unified",
    )
    st.plotly_chart(fig_comp, width="stretch")

    st.markdown("#### Scenario Summary Table")
    st.dataframe(pd.DataFrame(all_scenario_rows).set_index("Scenario"), width="stretch")

    # Historical correlation heatmap
    st.markdown("#### Gold–Market Correlation During Crises")
    st.caption("Negative or low correlation = gold acts as a hedge. Values closer to −1 = stronger inverse relationship.")
    corr_rows = []
    for sc_label, ev_list in EVENTS.items():
        for ev in ev_list:
            s, e = ev["start"], ev["end"]
            s = max(s, data.index[0].strftime("%Y-%m-%d"))
            window = data.loc[s:e]
            if len(window) < 10:
                continue
            mr = window.pct_change().dropna()
            corr = mr["GLD"].corr(mr["SPY"])
            corr_rows.append({"Scenario": sc_label, "Event": ev["name"], "Correlation": round(corr, 3)})

    if corr_rows:
        df_corr = pd.DataFrame(corr_rows)
        fig_corr = go.Figure(go.Bar(
            x=df_corr["Event"],
            y=df_corr["Correlation"],
            marker_color=["#FF4B4B" if c > 0.3 else "#4ECDC4" if c < 0 else "#FFA500"
                          for c in df_corr["Correlation"]],
            text=[f"{c:.2f}" for c in df_corr["Correlation"]],
            textposition="outside",
        ))
        fig_corr.add_hline(y=0, line_color="white", line_dash="dash", line_width=1)
        fig_corr.update_layout(
            template="plotly_dark", paper_bgcolor="#0e0e0e", plot_bgcolor="#131313",
            height=320, margin=dict(t=20, b=20),
            yaxis=dict(title="Pearson Correlation", range=[-0.6, 0.8]),
            xaxis_tickangle=-30,
        )
        st.plotly_chart(fig_corr, width="stretch")
